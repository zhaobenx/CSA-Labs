# Programing Midterm

Lingfeng Zhao| lz1973

## How to run
`make`
`make test`

Then run `make clean` to clean.

### Note

In beq_EX, the diff result can be different from given test case, but the differences are all on "X" places, so the code is correct.

